import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 福彩官网未开放 CORS，通过本地代理转发（dev / preview 均生效）
const cwlProxy = {
  '/cwl-api': {
    target: 'https://www.cwl.gov.cn',
    changeOrigin: true,
    rewrite: (path) => path.replace(/^\/cwl-api/, ''),
    headers: {
      Referer: 'https://www.cwl.gov.cn/ygkj/wqkjgg/kl8/',
    },
  },
}

export default defineConfig({
  plugins: [react()],
  server: { port: 5173, open: false, proxy: cwlProxy },
  preview: { proxy: cwlProxy },
})
