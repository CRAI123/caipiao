import React, { useState } from 'react'
import { HISTORY_DRAWS, SAMPLE_DRAWS } from './data/sample.js'
import Overview from './components/Overview.jsx'
import HotCold from './components/HotCold.jsx'
import Patterns from './components/Patterns.jsx'
import Repeats from './components/Repeats.jsx'
import DanTuo from './components/DanTuo.jsx'
import Predict from './components/Predict.jsx'
import DataManager from './components/DataManager.jsx'

const TABS = [
  { id: 'overview', label: '总览', en: 'OVERVIEW' },
  { id: 'hotcold', label: '冷热遗漏', en: 'HOT & COLD' },
  { id: 'patterns', label: '形态走势', en: 'PATTERNS' },
  { id: 'repeats', label: '重号斜连', en: 'REPEATS' },
  { id: 'dantuo', label: '复式胆拖', en: 'BETS' },
  { id: 'predict', label: '评分选号', en: 'SCORING' },
  { id: 'data', label: '数据管理', en: 'DATA' },
]

export default function App() {
  const [draws, setDraws] = useState(HISTORY_DRAWS.length ? HISTORY_DRAWS : SAMPLE_DRAWS)
  const [tab, setTab] = useState('overview')
  const usingSample = draws[0]?.sample

  return (
    <div className="app">
      {/* 顶部警示条 */}
      <div className="warn-strip" role="alert">
        <span className="warn-strip-inner">
          {Array.from({ length: 8 }).map((_, i) => (
            <span key={i}>
              ⚠️ 开奖为完全随机独立事件 · 本站所有统计仅供数据学习与复盘研究，不构成任何投注建议 · 理性购彩，量力而行，未满18周岁禁止购彩&nbsp;&nbsp;✦&nbsp;&nbsp;
            </span>
          ))}
        </span>
      </div>

      {/* 报头 */}
      <header className="masthead">
        <div className="masthead-inner">
          <div className="masthead-title">
            <span className="masthead-mark">研</span>
            <div>
              <h1>研彩室</h1>
              <p className="masthead-sub">
                福彩快乐8 · 数据研究档案 <i>KUAILE 8 RESEARCH LEDGER</i>
              </p>
            </div>
          </div>
          <div className="masthead-meta mono">
            <div>80 选 20 · 每期开出 20 个号码</div>
            <div>选十中十概率 1 / 8,911,711</div>
            <div className={usingSample ? 'meta-sample' : 'meta-real'}>
              数据源：{usingSample ? '内置演示数据' : '真实开奖数据'}
            </div>
          </div>
        </div>
      </header>

      {/* 导航 */}
      <nav className="tabs" aria-label="页面导航">
        {TABS.map((t) => (
          <button
            key={t.id}
            className={`tab-btn ${tab === t.id ? 'active' : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
            <i>{t.en}</i>
          </button>
        ))}
      </nav>

      <main className="main">
        {tab === 'overview' && <Overview draws={draws} />}
        {tab === 'hotcold' && <HotCold draws={draws} />}
        {tab === 'patterns' && <Patterns draws={draws} />}
        {tab === 'repeats' && <Repeats draws={draws} />}
        {tab === 'dantuo' && <DanTuo draws={draws} />}
        {tab === 'predict' && <Predict draws={draws} />}
        {tab === 'data' && <DataManager draws={draws} setDraws={setDraws} />}
      </main>

      <footer className="footer">
        <p>
          本站为开源学习工具，与 中国福利彩票发行管理中心 无任何关联。历史数据统计不改变任何一期的开奖概率；购买彩票的唯一理性理由是娱乐。
        </p>
        <p className="mono">research · not betting advice · 18+ only</p>
      </footer>
    </div>
  )
}
