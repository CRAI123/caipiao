// 启发式选号 —— 近期加权频次 + 遗漏打分，生成一组研究用号码
// ⚠️ 仅为历史数据的加权统计，不是概率模型，也不改变任何号码 25% 的开出概率
import React, { useMemo, useState } from 'react'
import { Card, Ball, BarList, Note, StatCard, pad2, yuan } from './common.jsx'
import {
  scoreBalls,
  range,
  comb,
  PLAY_LABEL,
  BALL_MAX,
  PRICE,
  takeLatest,
} from '../lib/stats.js'
import BetVerify from './BetVerify.jsx'

const MODES = [
  { id: 'hot', label: '偏热', desc: '只用近期加权频次（半衰期 20 期）' },
  { id: 'mix', label: '冷热兼顾', desc: '加权频次为主，叠加少量遗漏因素' },
  { id: 'cold', label: '偏冷', desc: '以当前遗漏期数为主' },
]

export default function Predict({ draws }) {
  const [hotMode, setHotMode] = useState('mix')
  const [play] = useState(10)

  const { scores, window } = useMemo(
    () => scoreBalls(draws, { periods: 100, halfLife: 20, hotMode }),
    [draws, hotMode],
  )

  const sorted = useMemo(
    () =>
      range(BALL_MAX)
        .map((n) => ({ n, s: +(scores[n] * 100).toFixed(1) }))
        .sort((a, b) => b.s - a.s),
    [scores],
  )

  const top20 = sorted.slice(0, 20)
  const recommend = sorted.slice(0, 12)
  const dans = recommend.slice(0, 4).map((x) => x.n)
  const tuos = recommend.slice(4).map((x) => x.n) // 8 个拖码

  const bet = useMemo(
    () => ({
      ok: true,
      mode: 'dantuo',
      play,
      dans,
      tuos,
      picks: null,
      count: comb(tuos.length, play - dans.length),
      cost: comb(tuos.length, play - dans.length) * PRICE,
      combos: null,
    }),
    [dans, tuos, play],
  )

  const latest = draws[0]
  const latestHit = new Set(latest.nums)
  const danHitNow = dans.filter((n) => latestHit.has(n)).length

  const costRows = [6, 7, 8].map((t) => ({ t, count: comb(t, play - dans.length), cost: comb(t, play - dans.length) * PRICE }))

  return (
    <div className="page">
      <div className="toolbar">
        <span className="toolbar-label">打分偏好</span>
        {MODES.map((m) => (
          <button
            key={m.id}
            className={`tab-btn ${hotMode === m.id ? 'active' : ''}`}
            onClick={() => setHotMode(m.id)}
          >
            {m.label}
          </button>
        ))}
        <span className="toolbar-note">样本 {window} 期 · 半衰期 20 期</span>
      </div>

      <Note tone="warn">
        <b>这不是预测模型。</b>快乐8 每期从 80 个号码中摇出 20 个，每个号码每期开出概率恒为 25%，期与期相互独立。
        下面只是把「最近出现多 / 遗漏久」的号码按历史权重排序，用于复盘研究；任何排序都不会改变中奖概率。
      </Note>

      <div className="stat-grid stat-grid-4">
        <StatCard label="参与打分号码" value={BALL_MAX} note="全部 80 个号码" />
        <StatCard label="单号每期理论概率" value="25" unit="%" tone="blue" note="20 / 80，固定不变" />
        <StatCard label="选十中十概率" value="1 / 8,911,711" tone="red" note="C(20,10)/C(80,10)" />
        <StatCard label="4 胆全中概率" value="0.306" unit="%" tone="amber" note="C(20,4)/C(80,4)" />
      </div>

      <div className="grid-2">
        <Card title="综合评分 TOP20" tag={`${MODES.find((m) => m.id === hotMode).desc}（分值为相对分）`}>
          <BarList
            items={top20.map((x) => ({ key: x.n, label: pad2(x.n), value: x.s }))}
            max={top20[0]?.s || 100}
            color="red"
          />
        </Card>
        <Card title={`研究用推荐号码（${PLAY_LABEL[play]}）`} tag="前 4 为胆码，其余为拖码">
          <div className="recommend-grid">
            {recommend.map(({ n, s }, i) => (
              <div key={n} className={`class-cell ${i < 4 ? 'cls-hot' : 'cls-warm'}`}>
                <Ball n={n} size="sm" />
                <span className="mono">{s}</span>
                <span className="miss mono">{i < 4 ? '胆' : '拖'}</span>
              </div>
            ))}
          </div>
          <p className="muted small">
            胆码：{dans.map(pad2).join(' ')} · 拖码：{tuos.map(pad2).join(' ')}
          </p>
          <Note>
            「推荐」只是按上面的评分顺序取前 12 个，没有任何保证。若想换一批号码，可切换上方的打分偏好。
          </Note>
        </Card>
      </div>

      <Card title="4 个胆码 + N 个拖码方案" tag={`${PLAY_LABEL[play]} · 胆码 ${dans.map(pad2).join(' ')}`}>
        <div className="table-scroll">
          <table className="ledger-table drag-table">
            <thead>
              <tr>
                <th>方案</th>
                <th>拖码</th>
                <th>注数</th>
                <th>金额</th>
                <th>头奖条件</th>
              </tr>
            </thead>
            <tbody>
              {costRows.map((r) => (
                <tr key={r.t} className={r.t === tuos.length ? 'row-active' : ''}>
                  <td>4 胆 + {r.t} 拖</td>
                  <td className="mono">{tuos.slice(0, r.t).map(pad2).join(' ')}</td>
                  <td className="mono">{r.count}</td>
                  <td className="mono">{yuan(r.cost)}</td>
                  <td className="muted small">
                    4 胆全中 + 拖码中 {play - dans.length} 个
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="result-bar" style={{ marginTop: 12 }}>
          <div>
            <b>默认方案 4 胆 + 8 拖：</b>
            <span className="result-count mono" style={{ marginLeft: 12 }}>{bet.count}</span>
            <span className="result-unit">注 · 合计 {yuan(bet.cost)}</span>
          </div>
        </div>
        <Note tone="warn">
          最近一期（{latest.id}）开奖中，这 4 个胆码命中 <b>{danHitNow}/4</b> 个。
          {danHitNow < 4 && '也就是说，按这组胆码生成的全部 28 注，当期都拿不到头奖——这正是胆拖的结构性风险：胆码全中才有高奖，胆码一错全组失效。'}
        </Note>
      </Card>

      <BetVerify bet={bet} draws={draws} />

      <Card title="为什么「算法预测」不可靠" className="concept-card">
        <ul className="concept-list">
          <li>摇奖机每期独立运行，历史开出次数不会「积累」成趋势；统计频次只能描述过去。</li>
          <li>80 个号码每个每期概率恒为 25%，冷热、遗漏、斜连都不改变这个数。</li>
          <li>复式与胆拖提高的是「覆盖的组合数」，成本同步增长；单位花费的中奖期望不变。</li>
          <li>过去 100 期看起来有「规律」，是因为人脑擅长在随机序列里寻找模式（错觉关联）。</li>
        </ul>
        <Note>
          因此本页的输出只适合当作选号的娱乐参考或复盘素材，<b>不要用它做投注决策</b>。若只是娱乐，建议固定小额预算。
        </Note>
      </Card>
    </div>
  )
}
